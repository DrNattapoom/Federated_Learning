from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10
import flwr as fl

# define the device allocation
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def load_data():
    """Load CIFAR-10 (training and test set)."""
    transform = transforms.Compose([   
        # converts a PIL Image or numpy.ndarray (H x W x C) in the range [0, 255] to a torch.FloatTensor of shape (C x H x W) 
        transforms.ToTensor(), 
        # normalize each color channel (red, green, blue)
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  
    ])
    # CIFAR10 = a popular colored image classification dataset for machine learning
    trainset = CIFAR10(".", train = True, download = True, transform=transform)
    testset = CIFAR10(".", train = False, download = True, transform=transform)
    # downloads the training and test data that are then normalized
    trainloader = DataLoader(trainset, batch_size = 32, shuffle = True)
    testloader = DataLoader(testset, batch_size = 32)
    return trainloader, testloader

def train(net, trainloader, epochs):
    """Train the network on the training set."""
    # define the loss and optimizer with PyTorch
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(net.parameters(), lr = 0.1, momentum = 1.0) # lr = learning rate
    # loop over the dataset to measure the corresponding loss and optimize it
    for _ in range(epochs):
        for images, labels in trainloader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(net(images), labels)
            loss.backward()
            optimizer.step()

def test(net, testloader):
    """Validate the network on the entire test set."""
    # define the validation
    criterion = torch.nn.CrossEntropyLoss()
    correct, total, loss = 0, 0, 0.0
    with torch.no_grad():
        # loop over the test set to measure the loss and accuracy of the test set.
        for data in testloader:
            images, labels = data[0].to(DEVICE), data[1].to(DEVICE)
            outputs = net(images)
            loss += criterion(outputs, labels).item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    accuracy = correct / total
    print("loss = ", loss)
    print("accuracy = ", accuracy)
    return loss, accuracy

class Net(nn.Module):
    def __init__(self) -> None:
        super(Net, self).__init__()
        # Conv2d parameters - (# of channels in the input image, # of channels produced by the convolution, size of the convolving kernel)
        # should not be changed --> not working
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        # Linear parameters - (size of each input sample, size of each output sample)
        # should not be changed --> not working
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Load model
net = Net()
# Load data
trainloader, testloader = load_data()

class CifarClient(fl.client.NumPyClient):
    # return the model weight as a list of NumPy ndarrays
    def get_parameters(self):
        return [val.cpu().numpy() for _, val in net.state_dict().items()]

    # update the local model weights with the parameters received from the server
    def set_parameters(self, parameters):
        params_dict = zip(net.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.Tensor(v) for k, v in params_dict})
        net.load_state_dict(state_dict, strict=True)

    # receive the updated local model weights
    def fit(self, parameters, config):
        # set the local model weights
        self.set_parameters(parameters)
        # train the local model
        train(net, trainloader, epochs = 1)
        return self.get_parameters(), len(trainloader), {}

    # test the local model
    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        loss, accuracy = test(net, testloader)
        return float(loss), len(testloader), {"accuracy":float(accuracy)}

fl.client.start_numpy_client("[::]:8080", client=CifarClient())

'''
NOTE: Play around with parameters

3 rounds with learning rate = 0.001 and momentum = 0.9 (Original)
--> loss = 471.1065 and accuracy = 0.4473

3 rounds with learning rate = 0.00001 and momentum = 0.9 (decrease learning rate)
--> loss = 721.3269 and accuracy = 0.1

3 rounds with learning rate = 0.1 and momentum = 0.9 (increase learning rate)
--> loss = 637.9387 and accuracy = 0.2119

3 rounds with learning rate = 0.001 and momentum = 0.8 (decrease momentum)
--> loss = 573.6223 and accuracy = 0.3306

3 rounds with learning rate = 0.001 and momentum = 1.0 (increase momentum)
--> loss = 774.5648 and accuracy = 0.1

3 rounds with learning rate = 0.00001 and momentum = 1.0 (decrease learning rate and increase momentum)
--> loss = 606.6001 and accuracy = 0.3147

3 rounds with learning rate = 0.00001 and momentum = 0.8 (decrease learning rate and decrease momentum)
--> loss = 721.6028 and accuracy = 0.1131

3 rounds with learning rate = 0.1 and momentum = 0.8 (increase learning rate and decrease momentum)
--> loss = 544.9343 and accuracy = 0.3914

3 rounds with learning rate = 0.1 and momentum = 1.0 (increase learning rate and increase momentum)
--> loss = 1160.8293 and accuracy = 0.1

5 rounds with learning rate = 0.001 and momentum = 0.9 (increase round)
--> loss = 418.0510 and accuracy = 0.5193
'''
